<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class SctweeterController extends Controller
{
    //
}
