<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Sctweet extends Model
{
    //
}
