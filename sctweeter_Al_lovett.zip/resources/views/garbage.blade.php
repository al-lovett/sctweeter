ignore me


<!-- $this->validate($request); -->
<!-- <form method="POST" action="">
  @csrf
    <input type="submit" name="delete" value="Delete Tweet">
</form> -->
<!--
Route::get('/playground', function(){
  $faker = Fake\Factory::create();

  for($i=0; $i<25; $i++){
    $user = array('name'=>$faker->name, 'email'=>$faker->email, 'password'=>\Hash::make('password'));
  };

}); -->

<!-- use App\User as User; -->
