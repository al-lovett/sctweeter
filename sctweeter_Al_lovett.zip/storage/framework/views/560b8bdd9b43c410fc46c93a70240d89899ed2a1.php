<?php $__env->startSection('content'); ?>
<div class="container-fluid">

    <!-- <div class="row justify-content-center"> -->
  <div class="row justify-content-center">
    <div class="">
      <div class="card-header">Dashboard
        <form class="" action="/tweet" method="post">
          <?php echo csrf_field(); ?>
            <textarea name="tweet" rows="10" cols="80"></textarea><br />

            <button class="btn btn-success"type="submit" name="button" >SCTweet Now</button>
        </form>

        <br>

        <div class="card" style="text-align: center">
          ScTweeter    <?php $__currentLoopData = $tweets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tweet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo e($tweet->tweet); ?> <br>
              <h4>Comments</h4>
              <?php $__currentLoopData = $tweet->comment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php echo e($comment->comments); ?>

              <a class="badge badge-primary centerclass" style="margin :auto" type="submit" href="/editcomment/<?php echo e($comment->id); ?>/edit">Edit Comment</a>
              <br>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <div class="">
                <form action="/comment" method="post"style="text-align: center">
                  <?php echo csrf_field(); ?>
                  <input type="hidden" name="tweet_id" value="<?php echo e($tweet->id); ?>"><br>
                    <textarea name="comment"> </textarea><br>
                    <button class="btn btn-primary" type="submit">Comment Below SCTweet</button>
                </form>

                <form action="/editTweet/<?php echo e($tweet->id); ?>/edit" method="get" style="text-align: center">
                  <input type="hidden" name="tweetId" value="<?php echo e($tweet->id); ?>">
                  <button class="btn btn-primary"type="submit">Edit SCTweet</button>
                </form>


              </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <!-- test delete -->

                <div class="card" style="text-align: center">
                <?php if(session('status')): ?>
                <div class="alert alert-success" role="alert">
                    <?php echo e(session('status')); ?>

                </div>
                  <?php endif; ?>

                  You are logged in!
                  <?php $__env->stopSection(); ?>
                    <a id="userprofile" class="badge badge-primary" href="<?php echo e(url('/profiles')); ?>">User Profile Page</a>
                </div>
        </div>
      </div>
    </div>
  </div>
</div>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sctweeter\resources\views/home.blade.php ENDPATH**/ ?>