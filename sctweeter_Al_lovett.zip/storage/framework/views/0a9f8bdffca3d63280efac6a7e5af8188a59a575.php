
<div id="centernav">
  <div class="navbar-nav">
    <a class="nav-item nav-link active" href="<?php echo e(url('/')); ?>">
      <?php echo e(config('app.name', 'Sapientia Commutationem')); ?>

    </a>
    <ul class="nav nav-pills">
        <?php if(auth()->guard()->guest()): ?>
            <li class="nav-item nav-link">
                <a href="<?php echo e(route('login')); ?>" class="badge badge-success"><?php echo e(__('Login')); ?></a>
            </li>
        <?php if(Route::has('register')): ?>
            <li class="nav-item nav-link">
                <a class="badge badge-success" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
                </li>
            <?php endif; ?>
        <?php else: ?>
            <li class="nav-item nav-link">
                <a id="" class="badge badge-success" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                    <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                </a>
                <form class="form-inline">
                  <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
                  <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
                </form>
            </li>
  <div class="nav-item" aria-labelledby="">
      <a class="badge badge-success" href="<?php echo e(route('logout')); ?>"
        onclick="event.preventDefault();
        document.getElementById('logout-form').submit();">
          <?php echo e(__('Logout')); ?>

      </a>
  <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
    <?php echo csrf_field(); ?>
  </form>
  </div>
    <?php endif; ?>
  </ul>
</div>
</div>
<?php /**PATH C:\laragon\www\sctweeter\resources\views/inc/navbar.blade.php ENDPATH**/ ?>