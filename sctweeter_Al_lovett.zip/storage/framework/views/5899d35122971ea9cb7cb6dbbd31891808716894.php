<?php $__env->startSection('content'); ?>

    <h1>User Profile Info</h1>
      <ul>
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li>
          <h2><?php echo e($user->name); ?><h2>

            <a href="<?php echo e('/profilesupdate/{id}'); ?>">
              Edit User Profile
            </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<br>
<br>
<br>

<a href="<?php echo e(route( 'home' )); ?>">Home Page</a>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sctweeter\resources\views/profiles.blade.php ENDPATH**/ ?>