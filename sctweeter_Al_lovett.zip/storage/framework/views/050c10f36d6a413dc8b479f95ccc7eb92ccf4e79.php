<?php $__env->startSection('content'); ?>


<div class="card-body">
    <h1> Update Comment</h1>
    <form class="" action="/editcomment/<?php echo e($comment->id); ?>/edit" method="post">
        <?php echo csrf_field(); ?>
        <textarea name="comment" rows="8" cols="80"><?php echo e($comment->comments); ?></textarea><br />


        <button type="submit" name="button" class="btn btn-success">Update Comment</button><br><br>
    </form>
    <form method="POST" action="<?php echo e(route( 'comment.destroy', $comment->id )); ?>">
      <?php echo csrf_field(); ?>
        <input type="submit" name="delete" value="Delete Comment" class="btn btn-success">
    </form>

</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sctweeter\resources\views/editcomment.blade.php ENDPATH**/ ?>